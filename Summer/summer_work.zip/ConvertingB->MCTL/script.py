import numpy as np

arr=np.genfromtxt('bdg341all', delimiter=',',skip_header=1)
c8=[]
x=np.reshape(arr[:,0],(-1,1))
c1=np.reshape(arr[:,1],(-1,1))
c7=np.reshape(arr[:,3],(-1,1))
c9=np.reshape(arr[:,4],(-1,1))

c9=1-c9

poop=np.concatenate((x,c9),axis=1)
np.savetxt('test.txt', poop, fmt='%1.6E', delimiter=' , ')
